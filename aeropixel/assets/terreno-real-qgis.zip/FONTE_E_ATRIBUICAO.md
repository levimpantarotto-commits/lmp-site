# Fonte, atribuição e limites

- DEM de origem: swissALTI3D 2 m, tile 2020 `2700-1118` — https://data.geo.admin.ch/ch.swisstopo.swissalti3d/swissalti3d_2020_2700-1118/swissalti3d_2020_2700-1118_2_2056_5728.tif
- Ortofoto: SWISSIMAGE pelo geosserviço oficial `ch.swisstopo.images-swissimage` — https://wms.geo.admin.ch/ (requisição usada no script: camada, EPSG:2056 e BBOX documentados em `baixar_terreno_real.py`). A data da imagem não foi confirmada nesta demonstração.
- Licença e condições de uso: https://www.swisstopo.admin.ch/en/terms-of-use-free-geodata-and-geoservices
- Atribuição obrigatória: © swisstopo.
- Recorte: Ticino, aproximadamente 46.21 N, 8.74 E; EPSG:2056.
- O visor web usa uma grade 257 × 257 (~3,9 m entre amostras) derivada do DEM de origem de 2 m; não representa a resolução nativa integral.
- Apenas visualização/cartografia demonstrativa: não há volume, lavra, classificação temática ou precisão validada.
